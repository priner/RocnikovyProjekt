Program hlada cyklicku suvislost a atomy kubickych grafov 
pouzivajuc (upraveny aby hladal aj atomy) alg. z clanku "An Algorithm for Cyclic Edge Connectivity of Cubic Graphs",
jeho autori: {Zdenek Dvor�k, Jan K�ra, Daniel Kr�l�, Ondrej Pangr�c}

Navod na pouzitie - v how_to_use.txt
Formaty vstupneho suboru - v about_input.txt
Ako pochopit output - v about_output.txt


Dufam ze to dava zmysel, v pripade otazok poslite mail.
	